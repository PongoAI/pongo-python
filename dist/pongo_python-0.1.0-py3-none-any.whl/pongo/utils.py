
BASE_URL = "https://warroom.joinpongo.com"
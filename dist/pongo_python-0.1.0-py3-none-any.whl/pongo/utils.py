
BASE_URL = "https://api.joinpongo.com"